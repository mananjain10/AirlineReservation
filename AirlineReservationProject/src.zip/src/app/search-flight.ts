export class SearchFlight {
    fromCity:string;
    toCity:string;
}
