import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userpassengerdetails',
  templateUrl: './userpassengerdetails.component.html',
  styleUrls: ['./userpassengerdetails.component.css']
})
export class UserpassengerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
