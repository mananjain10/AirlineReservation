import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminupdateflights',
  templateUrl: './adminupdateflights.component.html',
  styleUrls: ['./adminupdateflights.component.css']
})
export class AdminupdateflightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
