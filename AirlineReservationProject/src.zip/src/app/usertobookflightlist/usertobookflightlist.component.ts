import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usertobookflightlist',
  templateUrl: './usertobookflightlist.component.html',
  styleUrls: ['./usertobookflightlist.component.css']
})
export class UsertobookflightlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
