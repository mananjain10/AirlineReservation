import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usercancellations',
  templateUrl: './usercancellations.component.html',
  styleUrls: ['./usercancellations.component.css']
})
export class UsercancellationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
