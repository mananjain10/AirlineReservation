import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersearchflights',
  templateUrl: './usersearchflights.component.html',
  styleUrls: ['./usersearchflights.component.css']
})
export class UsersearchflightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
