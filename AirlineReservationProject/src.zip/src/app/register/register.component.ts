import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  regUser(regForm:NgForm)
  {
    if(regForm.valid)
    {
      alert("Successfully Registered");
    }
    else
    {
      alert("Invalid Data Entry")
    }
  }
}
