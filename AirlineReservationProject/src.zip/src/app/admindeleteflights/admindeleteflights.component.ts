import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindeleteflights',
  templateUrl: './admindeleteflights.component.html',
  styleUrls: ['./admindeleteflights.component.css']
})
export class AdmindeleteflightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
