export class User {
    userFName:string;
    userLName:string;
    userPassword:string;
    userEmail:string;
    userCity:string;
    userPhone:string;
    userName:string;
}
