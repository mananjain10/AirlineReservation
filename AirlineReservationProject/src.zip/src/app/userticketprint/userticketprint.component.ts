import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userticketprint',
  templateUrl: './userticketprint.component.html',
  styleUrls: ['./userticketprint.component.css']
})
export class UserticketprintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
