import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userseatmap',
  templateUrl: './userseatmap.component.html',
  styleUrls: ['./userseatmap.component.css']
})
export class UserseatmapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
