import { SearchFlight } from './search-flight';

describe('SearchFlight', () => {
  it('should create an instance', () => {
    expect(new SearchFlight()).toBeTruthy();
  });
});
