export class Loginuser {
    email: string;
    password: string;
}
