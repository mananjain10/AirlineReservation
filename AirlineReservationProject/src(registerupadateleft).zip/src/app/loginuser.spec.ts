import { Loginuser } from './loginuser';

describe('Loginuser', () => {
  it('should create an instance', () => {
    expect(new Loginuser()).toBeTruthy();
  });
});
