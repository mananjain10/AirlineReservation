export class User {
    title:string
    firstName:string;
    lastName:string;
    password:string;
    confirmPassword:string;
    email:string;
    dob:Date;
    phoneNo:string;
    wallet:number;
    userId:number
}
