import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userpayment',
  templateUrl: './userpayment.component.html',
  styleUrls: ['./userpayment.component.css']
})
export class UserpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
